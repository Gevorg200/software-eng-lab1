# INITIAL VERSION (Commit 1)
def start_calculator():
    print("Grade Calculator Engine Ready...")

# ADD THIS IN THE 'add' BRANCH (Commit 2)
def add_grades(grade_list):
    return sum(grade_list)

# ADD THIS IN THE 'mult' BRANCH (Commit 3)
def calculate_weighted_grade(grade, weight):
    # e.g., weight 0.2 for 20%
    return grade * weight