# System Configuration
UNIVERSITY_NAME = "University of Latvia"
FACULTY = "Faculty of Computing"
PASSING_GRADE = 4
MAX_GRADE = 10