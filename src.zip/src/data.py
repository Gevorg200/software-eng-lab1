# Data Storage
students_db = [
    {"name": "Armen", "grades": [7, 8, 9]},
    {"name": "Taron", "grades": [10, 9, 10]},
    {"name": "Anahit", "grades": [5, 4, 6]}
]

def get_all_students():
    return students_db